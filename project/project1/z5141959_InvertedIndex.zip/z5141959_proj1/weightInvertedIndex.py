import math
from mrjob.job import MRJob, MRStep
from mrjob.compat import jobconf_from_env


class weightInvertedIndex(MRJob):
    #   params:
    #   line: a line in the file. format: [docID term term term term]
    def mapper(self, _, line):
        term_frequency = {}
        if line.strip() != "":
            terms = line.strip().split()
            docID = terms[0]
            for i in range(1, len(terms)):
                if terms[i] not in term_frequency:
                    term_frequency[terms[i]] = 1

                    # use special key idea as a counter
                    # use -1 as key, make sure it appears before docID = 0
                    yield terms[i].lower() + "," + "-1", 1
                else:
                    term_frequency[terms[i]] += 1

            # emit ["term,docID", tf]
            # concatenate the term and docID by ",", so that we can use "," as seperator for partition and sort
            for term in term_frequency:
                yield term.lower() + "," + docID, term_frequency[term]


    # define marginal to store the value of special key. (i.e the total number of occurrence of a term in all document)
    # variable in reducer_init will be shared by all reducers.
    # dont need to return
    def reducer_init(self):
        self.marginal = 0

    #   params:
    #   key: term,docID
    #   values: [tf, tf, tf, tf]
    def reducer(self, key, values):
        term,docID = key.split(",")

        # deal with special key, aggregate the marginal
        if docID == "-1":
            self.marginal = sum(values)
        else:
            # aggregate the term frequency, then use marginal to calculate the tfidf.
            tf = sum(values)
            tfidf = tf * math.log10(int(jobconf_from_env('myjob.settings.docnumber')) / self.marginal)
            yield term, docID + ", " + str(tfidf)


    def steps(self):
        return [
            MRStep(mapper=self.mapper,
                   reducer_init=self.reducer_init,
                   reducer=self.reducer)
        ]

    SORT_VALUES = True

    JOBCONF = {
        'mapreduce.map.output.key.field.separator': ',',
        'mapreduce.partition.keypartitioner.options': '-k1,1', # partition by term
        'partitioner': 'org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner',
        'mapreduce.job.output.key.comparator.class': 'org.apache.hadoop.mapreduce.lib.partition.KeyFieldBasedComparator',
        'mapreduce.partition.keycomparator.options': '-k1,1 -k2,2n' # first sort by term,  secondary sort by docID numerically
    }


if __name__ == '__main__':
    weightInvertedIndex.run()
